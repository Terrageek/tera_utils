# tera_utils


* This project is mostly built for fun and includes module that I wrote*.

* It is meant as a learning exercise not as a package to use out side of pet project.

* Names, Parameters, Function, and Classes are subject to change between versions!!!




\* If I could not code it my self or needed a solution while working on an other module I some times   copy code from other developers, The GitHub link to his/her page is commented ate the first line of 
the module.
It is my intent to only use build in module or essential module PyPi at the end of this projects life cycle.